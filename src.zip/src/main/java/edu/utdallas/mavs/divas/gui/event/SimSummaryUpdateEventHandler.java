package edu.utdallas.mavs.divas.gui.event;

import com.pennychecker.eventbus.EventHandler;

public interface SimSummaryUpdateEventHandler extends EventHandler
{
    void onSimSummaryUpdateEvent(SimSummaryUpdateEvent event);
}
