package edu.utdallas.mavs.divas.gui.mvp.view.swing.handlers;

import edu.utdallas.mavs.divas.gui.mvp.view.swing.frames.agentspec.AgentSpecFrame;
import edu.utdallas.mavs.divas.gui.mvp.view.swing.frames.agentspec.MetaAgentSpecFrame;
import edu.utdallas.mavs.divas.gui.services.process.ProcessLauncher;

public class ToolsMenuHandler
{
    public void openMetaAgentSpecFrame()
    {
        ProcessLauncher maslauncher = new ProcessLauncher();
        maslauncher.start(MetaAgentSpecFrame.class, 256);
    }

    public void openAgentSpecFrame()
    {
        ProcessLauncher aslauncher = new ProcessLauncher();
        aslauncher.start(AgentSpecFrame.class, 256);
    }
}
