package edu.utdallas.mavs.divas.gui.mvp.view.swing.handlers;

public class FileMenuHandler
{
    public FileMenuHandler()
    {}

    public void exit()
    {
        System.exit(0);
    }
}
