/**
 * 
 */
package edu.utdallas.mavs.divas.gui.mvp.model;

/**
 * 
 */
public class CellSummary
{

}
