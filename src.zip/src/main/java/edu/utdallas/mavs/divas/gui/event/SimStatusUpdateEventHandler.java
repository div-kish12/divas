package edu.utdallas.mavs.divas.gui.event;

import com.pennychecker.eventbus.EventHandler;

public interface SimStatusUpdateEventHandler extends EventHandler
{
    void onSimStatusUpdateEvent(SimStatusUpdateEvent event);
}
